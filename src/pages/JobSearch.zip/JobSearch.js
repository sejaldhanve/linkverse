import React, { useState } from "react";
import TextField from "@mui/material/TextField";
import Slider from "@mui/material/Slider";

const jobs = [
  {
    title: "Adidas",
    image: "https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcT2B9LswCEh3jElEIiDsU4C60RTU3Chlv-h2A&s",
    message: "Lorem ipsum dolor sit amet, consectetur adipiscing elit.",
  },
  {
    title: "Apple",
    image: "https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcS2vCOGbSxOES4ol-sz6p9uWrkInrPtguzTJQ&s",
    message: "Lorem ipsum dolor sit amet, consectetur adipiscing elit.",
  },
  {
    title: "Goldman Sachs",
    message: "Lorem ipsum dolor sit amet, consectetur adipiscing elit.",
  },
  {
    title: "Charlie Chaplin",
    image: "https://static.vecteezy.com/system/resources/previews/019/136/322/non_2x/amazon-logo-amazon-icon-free-free-vector.jpg",
    message: "Lorem ipsum dolor sit amet, consectetur adipiscing elit.",
  },
];

export default function JobSearch() {
  const [salaryRange, setSalaryRange] = useState([30000, 100000]);

  const handleSalaryChange = (event, newValue) => {
    setSalaryRange(newValue);
  };

  const resetFilters = () => {
    setSalaryRange([30000, 100000]);
    // Reset other filters (like text fields, checkboxes, etc.)
  };

  return (
    <div className="jobSearch">
      <center>
        <div className="searchContainer">
          <TextField
            className="searchBar"
            label="Job title, Keywords or Company Name"
            variant="outlined"
          />
          <button className="searchButton">Search</button>
        </div>
      </center>
      <div className="jobSearchContent">
        <div className="filter">
          <center>
            <h1>Filter</h1>
          </center>

          <p>Job Type</p>
          <div className="jobType">
            <label>
              <input type="checkbox" name="jobType" value="Full-Time" />
              Full-Time
            </label>
            <label>
              <input type="checkbox" name="jobType" value="Part-Time" />
              Part-Time
            </label>
            <label>
              <input type="checkbox" name="jobType" value="Internship" />
              Internship
            </label>
            <label>
              <input type="checkbox" name="jobType" value="Contract" />
              Contract
            </label>
            <label>
              <input type="checkbox" name="jobType" value="Volunteer" />
              Volunteer
            </label>
          </div>
          <p>Location</p>
          <TextField label="Enter your Location" />
          <p className="exp_level">Experience Level</p>
          <select name="experience" id="experience">
            <option value="fresher">Fresher</option>
            <option value="intermediate">Intermediate</option>
            <option value="internship">Internship</option>
            <option value="apprenticeship">Apprenticeship</option>
            <option value="freelancing">Freelancing</option>
            <option value="other">Other</option>
          </select>
          <p>Salary Range</p>
          <Slider
            value={salaryRange}
            onChange={handleSalaryChange}
            valueLabelDisplay="auto"
            valueLabelFormat={(value) => `$${value.toLocaleString()}`}
            min={20000}
            max={200000}
            step={5000}
            marks
          />
          <div className="salaryRangeDisplay">
            <h4>From: ${salaryRange[0].toLocaleString()}</h4>
            <h4 className="rangedisplay">To: ${salaryRange[1].toLocaleString()}</h4>
          </div>
          <p>Currency</p>
          <select name="currency" id="currency">
            <option value="dollar">Dollar($)</option>
            <option value="euro">Euro</option>
            <option value="japanese yen">Japanese Yen</option>
            <option value="gbp">GBP</option>
          </select>
          <center><button onClick={resetFilters}>Reset all Filter</button></center>
        </div>
        <div className="jobs">
          <div className="jobs_section">
            {jobs.map((job, index) => (
              <div className="applied_jobs" key={index}>
                <img className="job_logo" src={job.image} alt={job.title} />
                <center><h3 className="job_title">{job.title}</h3></center>
                <p className="job_description">{job.message}</p>
              </div>
            ))}
          </div>
        </div>

        <div className="savedJobs">
          <p>Saved Jobs</p>
        </div>
      </div>
    </div>
  );
}
